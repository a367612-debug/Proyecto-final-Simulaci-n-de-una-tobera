@echo off
rem Tobera C-D, nivel 1, caso A: supersonico adaptado (diseno, Me = 1.534). blueCFD-Core 2024 (OpenFOAM 12), solver shockFluid.
rem Uso, desde la terminal cmd de blueCFD y en la carpeta del caso:  Allrun.bat        (malla base, nR = 30)
rem                                                                  Allrun.bat 45     (otra malla)
rem Malla con Gmsh (sin chorro), gmshToFoam, tipos de los parches, checkMesh y foamRun. Gmsh tiene que estar en el PATH.
setlocal
cd /d %~dp0
set nR=%1
if "%nR%"=="" set nR=30

where gmsh > nul 2>&1 || (echo No se encuentra gmsh: agregue su carpeta al PATH, por ejemplo& echo     set PATH=%%PATH%%;C:\gmsh-4.15.2-Windows64& exit /b 1)
call gmsh tobera.geo -3 -setnumber chorro 0 -setnumber nR %nR% -o tobera.msh -log log.gmsh > nul 2>&1 || goto fallo
gmshToFoam tobera.msh > log.gmshToFoam 2>&1 || goto fallo
foamDictionary constant/polyMesh/boundary -entry entry0/frontAndBack/type -set empty > log.foamDictionary 2>&1 || goto fallo
foamDictionary constant/polyMesh/boundary -entry entry0/nozzleWall/type -set wall >> log.foamDictionary 2>&1 || goto fallo
checkMesh > log.checkMesh 2>&1 || goto fallo
foamRun > log.foamRun 2>&1 || goto fallo
echo Listo. Comparacion con la teoria, desde la carpeta de arriba:  python postproceso.py Tobera_A
goto :eof

:fallo
echo Fallo un paso: revisa el ultimo log.* de la carpeta del caso.
exit /b 1
