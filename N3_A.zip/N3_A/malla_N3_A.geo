// Tobera convergente-divergente con el chorro (tutorial 2.3). Parte de CDNozzlev2.geo: la misma forma, en
// bloques de cuatro lados, pero con los tamaños de celda empalmados, sin suavizado y con grupos que no dependen de
// índices copiados. Se construye media tobera, del eje a la pared; la plana es esa mitad y su espejo, y la
// axisimétrica es la misma mitad girada unos grados alrededor del eje (una cuña).
//   gmsh malla_N3_A.geo -3 -o tobera.msh
//   gmsh malla_N3_A.geo -3 -setnumber tipo 1 -o cuna.msh
// MODIFICACIÓN (equipo): parámetro 'chorro'. Con chorro = 0 el dominio termina en el plano de salida de la
// tobera (nivel 1); con chorro = 1 queda igual que el original (nivel 2). Razón de áreas por defecto: 1.2.
//   gmsh malla_N3_A.geo -3 -setnumber chorro 0 -o interna.msh
//   gmsh malla_N3_A.geo -3 -setnumber chorro 1 -o chorro.msh

SetFactory("Built-in");

DefineConstant[
  tipo  = {0,   Choices{0 = "Plana", 1 = "Axisimétrica (cuña)"}, Name "1Tobera/1Tipo"},
  AR    = {1.2,   Name "1Tobera/2Razón de áreas Ae entre At"},
  He    = {1,   Name "1Tobera/3Semialtura de salida He (m)"},
  Lc    = {2,   Name "1Tobera/4Longitud del convergente (m)"},
  Ld    = {4,   Name "1Tobera/5Longitud del divergente (m)"},
  gam   = {1.4, Name "1Tobera/6Razón de calores γ"},
  chorro = {1, Choices{0 = "Sin chorro (nivel 1)", 1 = "Con chorro (nivel 2)"}, Name "2Chorro/0Dominio"},
  fDown = {8,   Name "2Chorro/1Longitud aguas abajo (diámetros)"},
  fFar  = {6,   Name "2Chorro/2Semialtura del dominio (He)"},
  nR    = {30,  Name "3Malla/1Celdas en la semialtura"},
  fLej  = {0.5, Name "3Malla/2Celda del campo lejano (He)"},
  pared = {1, Choices{0 = "Sin capas (niveles 1 y 2)", 1 = "Capas de pared (nivel 3)"}, Name "3Malla/3Capas de pared"},
  nW    = {60,   Name "3Malla/4Celdas en la semialtura con capas"},
  yW    = {7e-5, Name "3Malla/5Primera celda en la pared, garganta (m)"},
  e     = {0.1, Name "4OpenFOAM/1Espesor, tobera plana (m)"},
  cuna  = {5,   Name "4OpenFOAM/2Ángulo de la cuña (grados)"}
];

// ---------------------------------------------------------------- la garganta sale de la razón de áreas
// En la plana el área es proporcional a la semialtura; en la axisimétrica, al cuadrado del radio. La misma razón
// de áreas pide gargantas distintas.
If (tipo == 0)
  Ht = He / AR;
Else
  Ht = He / Sqrt(AR);
EndIf

// Mach de diseño: la rama supersónica de A/A* = (1/M) [2/(γ+1) (1 + (γ−1)/2 M²)]^((γ+1)/(2(γ−1))), por bisección
// (la razón de áreas crece con M en la rama supersónica).
mA = 1.0;  mB = 50.0;
For iter In {1:100}
  mM = 0.5 * (mA + mB);
  aM = (1 / mM) * ((2 / (gam + 1)) * (1 + 0.5 * (gam - 1) * mM^2))^((gam + 1) / (2 * (gam - 1)));
  If (aM < AR)
    mA = mM;
  Else
    mB = mM;
  EndIf
EndFor
Me = 0.5 * (mA + mB);
p0pe = (1 + 0.5 * (gam - 1) * Me^2)^(gam / (gam - 1));   // presión de remanso entre presión de salida, en diseño

// ---------------------------------------------------------------- posiciones
xt = Lc;              // garganta
xe = Lc + Ld;         // salida de la tobera
xo = xe + fDown * 2 * He;
Hf = fFar * He;

// ---------------------------------------------------------------- tamaños de celda: mandan, no los conteos
// Celdas cuadradas en la garganta y en la salida: nR celdas en la semialtura y el mismo largo a lo largo del eje.
hT = Ht / nR;
hE = He / nR;
hF = fLej * He;

// La progresión que empalma dos tamaños (la macro del 2.2.2): reparte eL en celdas que van de eh1 a ehN.
Macro Empalme
  eR = (eL - eh1) / (eL - ehN);
  eN = 2 + Floor(Log(ehN / eh1) / Log(eR) + 0.5);
Return

// ---------------------------------------------------------------- capas de pared (nivel 3)
// Las lineas radiales van del eje a la pared con nW celdas que crecen hacia el eje con razon rW. rW se elige para
// que la primera celda junto a la pared de la garganta mida yW: Ht (rW - 1) / (rW^nW - 1) = yW (biseccion).
nRad = nR;  rW = 1.0;
If (pared == 1)
  nRad = nW;
  rA_ = 1.0001;  rB_ = 2.0;
  For iter In {1:200}
    rM_ = 0.5 * (rA_ + rB_);
    yM_ = Ht * (rM_ - 1) / (rM_^nW - 1);
    If (yM_ > yW)
      rA_ = rM_;
    Else
      rB_ = rM_;
    EndIf
  EndFor
  rW = 0.5 * (rA_ + rB_);
EndIf
yWe = He * (rW - 1) / (rW^nRad - 1);                  // primera celda en la salida y en el labio
If (pared == 0)
  yWe = hE;
EndIf

eL = Lc;            eh1 = hT;  ehN = hE;  Call Empalme;
nC = eN;  rC = eR;                                    // convergente, de la garganta a la entrada
eL = Ld;            eh1 = hT;  ehN = hE;  Call Empalme;
nD = eN;  rD = eR;                                    // divergente, de la garganta a la salida
eL = xo - xe;       eh1 = hE;  ehN = hF;  Call Empalme;
nJ = eN;  rJ = eR;                                    // chorro, de la salida al final del dominio
eL = Hf - He;       eh1 = yWe; ehN = hF;  Call Empalme;
nA = eN;  rA = eR;                                    // ambiente, del labio de la tobera hacia arriba

If (chorro == 1)
  mitad = nRad * (nC - 1 + nD - 1 + nJ - 1) + (nA - 1) * (nJ - 1);
Else
  mitad = nRad * (nC - 1 + nD - 1);
EndIf
If (tipo == 0)
  celdas = 2 * mitad;
Else
  celdas = mitad;
EndIf

Printf("garganta Ht = %g m   Mach de diseño Me = %g   p0/pe de diseño = %g (pe/p0 = %g)", Ht, Me, p0pe, 1 / p0pe);
Printf("celdas: garganta %g m, salida %g m, campo lejano %g m", hT, hE, hF);
Printf("convergente: %g nodos, progresión %g   divergente: %g nodos, progresión %g", nC, rC, nD, rD);
Printf("chorro: %g nodos, progresión %g   ambiente: %g nodos, progresión %g", nJ, rJ, nA, rA);
Printf("celdas previstas: %g", celdas);
If (pared == 1)
  Printf("capas de pared: %g celdas radiales, crecimiento %g, primera celda %g m (garganta) y %g m (salida)", nW, rW, yW, yWe);
EndIf

// ---------------------------------------------------------------- las mitades
// La plana lleva dos mitades, la de arriba (sg = 1) y su espejo (sg = −1); la cuña, sólo la de arriba. El espejo no
// se hace con Symmetry { Duplicata {...} }: la copia no hereda Transfinite ni Recombine, y la mitad de abajo se
// mallaría con triángulos. Cada mitad se escribe entera, con sus propios números: o = 0 arriba, o = 20 abajo.
If (tipo == 0)
  nLados = 2;
Else
  nLados = 1;
EndIf

// Los puntos del eje y las tres líneas del eje son de las dos mitades.
Point(1) = {0, 0, 0};    Point(2) = {xt, 0, 0};    Point(3) = {xe, 0, 0};    Point(4) = {xo, 0, 0};
Line(1) = {2, 1};                                     // eje del convergente (las axiales parten de la garganta)
Line(2) = {2, 3};                                     // eje del divergente
If (chorro == 1)
  Line(3) = {3, 4};                                   // eje del chorro
EndIf

// La pared: H = Ht + (He − Ht)(1 − cos πs)/2, con s de 0 en la garganta a 1 en la entrada o en la salida. La
// pendiente es cero en la garganta, pero la Spline sale de cada extremo con la pendiente de su primera cuerda: con
// 5 puntos el quiebre en la garganta pasa de un grado; con 200, un tercio. Los puntos van a pasos iguales en s:
// Transfinite sigue la parametrización de la Spline, y con los puntos apiñados en los extremos las celdas de la
// pared dejan de crecer con la razón pedida.
nP = 200;
sup[] = {};
For lado In {0 : nLados - 1}
  sg = 1 - 2 * lado;
  o = 20 * lado;
  w = 2000 * lado;                                    // puntos de la pared: 1000s y 2000s arriba, 3000s y 4000s abajo
  Point(5 + o) = {0,  sg * He, 0};   Point(6 + o) = {xt, sg * Ht, 0};
  Point(7 + o) = {xe, sg * He, 0};
  If (chorro == 1)
    Point(8 + o) = {xo, sg * He, 0};
    Point(9 + o) = {xe, sg * Hf, 0};   Point(10 + o) = {xo, sg * Hf, 0};
  EndIf
  For i In {1 : nP - 1}
    s = i / nP;
    Hs = Ht + (He - Ht) * 0.5 * (1 - Cos(Pi * s));
    Point(w + 1000 + i) = {xt - Lc * s, sg * Hs, 0};  // convergente
    Point(w + 2000 + i) = {xt + Ld * s, sg * Hs, 0};  // divergente
  EndFor
  Hide { Point{w + 1001 : w + 1000 + nP - 1, w + 2001 : w + 2000 + nP - 1}; }

  Spline(4 + o) = {6 + o, w + 1001 : w + 1000 + nP - 1, 5 + o};    // pared del convergente
  Spline(5 + o) = {6 + o, w + 2001 : w + 2000 + nP - 1, 7 + o};    // pared del divergente
  Line(6 + o) = {1, 5 + o};   Line(7 + o) = {2, 6 + o};              // entrada, garganta
  Line(8 + o) = {3, 7 + o};                                          // salida de la tobera
  If (chorro == 1)
    Line(9 + o) = {4, 8 + o};                                        // final del dominio
    Line(10 + o) = {7 + o, 8 + o};                                   // borde del chorro, desde el labio
    Line(11 + o) = {7 + o, 9 + o};  Line(12 + o) = {8 + o, 10 + o};  Line(13 + o) = {9 + o, 10 + o};   // ambiente
  EndIf

  // Cuatro bloques. Abajo el espejo invierte el sentido de cada lazo: se recorren al revés para que todos
  // giren contra las manecillas del reloj.
  If (sg > 0)
    Curve Loop(1) = {7, 4, -6, -1};      Plane Surface(1) = {1};      // convergente
    Curve Loop(2) = {2, 8, -5, -7};      Plane Surface(2) = {2};      // divergente
    If (chorro == 1)
      Curve Loop(3) = {3, 9, -10, -8};     Plane Surface(3) = {3};    // núcleo del chorro
      Curve Loop(4) = {10, 12, -13, -11};  Plane Surface(4) = {4};    // ambiente
    EndIf
  Else
    Curve Loop(21) = {1, 26, -24, -27};  Plane Surface(21) = {21};
    Curve Loop(22) = {27, 25, -28, -2};  Plane Surface(22) = {22};
    If (chorro == 1)
      Curve Loop(23) = {28, 30, -29, -3};  Plane Surface(23) = {23};
      Curve Loop(24) = {31, 33, -32, -30}; Plane Surface(24) = {24};
    EndIf
  EndIf

  Transfinite Curve {4 + o} = nC Using Progression rC;
  Transfinite Curve {5 + o} = nD Using Progression rD;
  If (pared == 1)
    Transfinite Curve {6 + o, 7 + o, 8 + o} = nRad + 1 Using Progression 1 / rW;   // celdas finas junto a la pared
  Else
    Transfinite Curve {6 + o, 7 + o, 8 + o} = nRad + 1;
  EndIf
  If (chorro == 1)
    Transfinite Curve {10 + o, 13 + o} = nJ Using Progression rJ;
    If (pared == 1)
      Transfinite Curve {9 + o} = nRad + 1 Using Progression 1 / rW;
    Else
      Transfinite Curve {9 + o} = nRad + 1;
    EndIf
    Transfinite Curve {11 + o, 12 + o} = nA Using Progression rA;
    sup[] += {1 + o : 4 + o};
  Else
    sup[] += {1 + o : 2 + o};
  EndIf
EndFor
Transfinite Curve {1} = nC Using Progression rC;
Transfinite Curve {2} = nD Using Progression rD;
If (chorro == 1)
  Transfinite Curve {3} = nJ Using Progression rJ;
EndIf
Transfinite Surface {sup[]};
Recombine Surface {sup[]};
Mesh.Smoothing = 0;       // el suavizado mueve los nodos que Transfinite acaba de colocar

// ---------------------------------------------------------------- la extrusión: una capa, o la cuña
If (tipo == 0)
  ext[] = Extrude {0, 0, e} { Surface{sup[]}; Layers{1}; Recombine; };
Else
  // La cuña queda simétrica respecto del plano z = 0: se gira media cuña hacia atrás y se extruye la cuña entera.
  Rotate {{1, 0, 0}, {0, 0, 0}, -cuna / 2 * Pi / 180} { Surface{sup[]}; }
  ext[] = Extrude {{1, 0, 0}, {0, 0, 0}, cuna * Pi / 180} { Surface{sup[]}; Layers{1}; Recombine; };
EndIf

// ---------------------------------------------------------------- grupos físicos: por posición, no por índice
// Extrude no devuelve la misma lista en los dos casos: en la cuña, las caras del eje degeneran en una línea y
// desaparecen de la lista. Se eligen las caras por la caja que las contiene (Surface In BoundingBox), con cajas
// que sirven para la mitad de arriba, la de abajo y la cuña girada: en ésta, la pared baja hasta y = Ht cos(cuña/2).
eps = 1e-6;
c2 = Cos(cuna / 2 * Pi / 180);
Z = Hf;                                               // cualquier z: la plana y la cuña caben en ±Hf

entrada[] = Surface In BoundingBox {-eps, -He - eps, -Z, eps, He + eps, Z};
paredArr[] = Surface In BoundingBox {-eps, Ht * c2 - eps, -Z, xe + eps, He + eps, Z};
paredAba[] = Surface In BoundingBox {-eps, -He - eps, -Z, xe + eps, -Ht + eps, Z};
If (chorro == 1)
  salida[] = Surface In BoundingBox {xo - eps, -Hf - eps, -Z, xo + eps, Hf + eps, Z};
  techo[] = Surface In BoundingBox {xe - eps, Hf * c2 - eps, -Z, xo + eps, Hf + eps, Z};
  piso[] = Surface In BoundingBox {xe - eps, -Hf - eps, -Z, xo + eps, -Hf + eps, Z};
  labioArr[] = Surface In BoundingBox {xe - eps, He * c2 - eps, -Z, xe + eps, Hf + eps, Z};
  labioAba[] = Surface In BoundingBox {xe - eps, -Hf - eps, -Z, xe + eps, -He + eps, Z};
Else
  // Nivel 1: la salida es el plano x = xe de la tobera; no hay campo lejano.
  salida[] = Surface In BoundingBox {xe - eps, -He - eps, -Z, xe + eps, He + eps, Z};
  techo[] = {};  piso[] = {};  labioArr[] = {};  labioAba[] = {};
EndIf

Physical Surface("inlet")      = {entrada[]};
Physical Surface("nozzleWall") = {paredArr[], paredAba[]};
Physical Surface("outlet")     = {salida[]};
If (chorro == 1)
  Physical Surface("farField")   = {techo[], piso[], labioArr[], labioAba[]};
EndIf

If (tipo == 0)
  frente[] = Surface In BoundingBox {-eps, -Hf - eps, -eps, xo + eps, Hf + eps, eps};
  atras[] = Surface In BoundingBox {-eps, -Hf - eps, e - eps, xo + eps, Hf + eps, e + eps};
  Physical Surface("frontAndBack") = {frente[], atras[]};
Else
  sz = Hf * Sin(cuna / 2 * Pi / 180);
  frente[] = Surface In BoundingBox {-eps, -eps, -sz - eps, xo + eps, Hf + eps, eps};
  atras[] = Surface In BoundingBox {-eps, -eps, -eps, xo + eps, Hf + eps, sz + eps};
  Physical Surface("wedgeFront") = {frente[]};
  Physical Surface("wedgeBack")  = {atras[]};
EndIf
Physical Volume("fluid") = Volume In BoundingBox {-eps, -Hf - eps, -Z, xo + eps, Hf + eps, Z};

Printf("caras: entrada %g, pared %g, salida %g, campo lejano %g, frente %g, atrás %g", #entrada[],
       #paredArr[] + #paredAba[], #salida[], #techo[] + #piso[] + #labioArr[] + #labioAba[], #frente[], #atras[]);

Mesh.MshFileVersion = 2.2;   // gmshToFoam sólo lee MSH 2 ASCII
Mesh.Binary = 0;